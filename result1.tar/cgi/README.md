CGI Example Code - C server-side example, Python client examples; note: it doesn't show sending of content via stdin etc.
Daemonizing C Code - helper daemonizing code

echo_server: $(OBJ_DIR)/echo_server.o $(OBJ_DIR)/y.tab.o $(OBJ_DIR)/lex.yy.o $(OBJ_DIR)/parse.o
in makefile

cd /Users/chenkaixuan/Desktop/课内/计算机网络/实验/core/webServerStartCodes-2025 && ./test_echo_server.sh